const storyData = require("./story")
const aboutData = require("./about")
const educationData = require("./education")

module.exports = {
    story: storyData,
    education : educationData,
    about : aboutData
}