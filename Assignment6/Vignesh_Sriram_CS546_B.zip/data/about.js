let exportedMethods = {

    getAbout(){
        var a = {
        "name": "Vignesh Sriram",
        "cwid": "10430312",
        "biography": "Hi! My name is Vignesh Sriram and I am DESILOPER.\n Confused? Well thats not any mythological creature.\n Its a mixture of Designer and Developer..",
        "favoriteShows": ["Friends", "GOT", "Narcos", "Tom and Jerry"],
        "hobbies": ["Football", "Cricket", "Chess"]
        }
        return a;
      }
    }
    
    module.exports = exportedMethods;