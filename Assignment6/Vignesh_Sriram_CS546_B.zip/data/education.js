
let exportedMethods = {
    getEducation(){
        var a = [
            {
              "schoolName": "I.E.S. Manik Vidyamandir",
              "degree": "SSC",
              "favoriteClass": "7th",
              "favoriteMemory": "The Chalk Fight:\
              Sweet and innocent from the outside but devils inside, this was how my class teacher described me and my group. And well she wasn't wrong. We had done all the things which a 6th grader wouldn't even dream of doing. Played football in the classroom? Yes. Broken tube lights? Yes. Stuck chewing gums on our teachers? Oh Yes!!. The school was a fun place until we realized we had competition. Our history teacher in one of her lecture said 4-5 boys in the other class were the most troublesome students she had ever seen. And we were like HOW DARE YOU SAY THAT IN FRONT OF US? We had maintained that title for years and she so easily gave it away. We were curious to find out who these new runts were but more than being curious we were desperate to get that title back. So during the lunch break, we went to investigate about our rivals. We didn't go empty handed but, we took our weapons along with us- CHALKS. Now Each class in our school had a different feel to it like you felt at home when you were in your class but other classes felt like alien worlds. We entered their class and saw that they were sitting on the last bench. I and my group got out missiles ready and projected it towards them with all our might as if our lives depended on it. Now there were some losers in my group who would miss a target which was 2 feet away. Asking them to hurl chalks till the last bench was like asking a newborn to solve Ph.D. level maths (That was a terrible metaphor but I hope you get the equation). Now as expected these losers hurled the chalks at some other students. Now the plan was to attack and run but this never crossed our mind that there is something called as backfire from the enemy. And because of some of our great archers, we had made a lot of enemies and that also within a span of 3 seconds. If the Guinness guys were watching this we would have received the world record for making the most enemies in 3 seconds. Now we had not only those 4-5 guys behind us but their entire class was chasing us with chalks in their hands. We ran back to our class sweet class and hid under the last bench. The guys from the other class started throwing chalks at us but guess what even those guys had losers like us who were seeing right and throwing left. Some group eating quietly in the corner was showered with chalks they shut their lunch boxes and joined the war. We were not alone. And within no time the entire class was with us. With every new kid joining our weapons kept upgrading. Now we had new weapons: Paper balls, Pen caps, erasers, water and the ultimate bags. It was a havoc. The classroom looked no different than a war zone. Chalks and erasers flying in each direction. And after a fierce battle, we finally managed to chase them out. The principal gave 3 days off to both the classes and asked them to chill at home. He called it a suspension. After 3 days when we came back to school our history teacher looked at us and said this is the worst class ever. And we all looked at each other and just smiled. Mission Accomplished."
            },

            {
                "schoolName": "R.D National College",
                "degree": "HSC",
                "favoriteClass": "11th",
                "favoriteMemory": "Parent Teacher Meetings\
                I dont know why many of the students feared the Parents teachers meeting. I still remember on of the guy in my college had paid 100 bucks to a auto driver to act as his dad during the meeting. Dad knew that I was excellent in my studies so he never bothered about such meetings. But our college had made it mandatory for parents to attend these meetings. Dad came at 9 am as told by the college people. And this was the talk which he had the teacher. Maths Teacher: He comes late to the school everyday. Dad: At least he comes. I have to put in a lot of effort to wake him up every morning. And that wasn't all. There was some more savage. There was a teacher who didn't like me EVS teacher : I have a lot of complaints regarding him though he is good in studies he... Dad : I don't have time for it. I have a meeting. Tell me where to put my signature. Others called it a nightmare. I loved Parents teachers meetings"
              },

              {
                "schoolName": "PVPP COE",
                "degree": "BE",
                "favoriteClass": "Third Year",
                "favoriteMemory": "The phone call\
                Our college had some strict rules- not to let students go outside the campus until 4 pm. I was in the 1st year of Engineering and had just completed a project. I needed a day off but I knew the would not be let out the college. So I told the staff that I wasn't feeling well and asked them for a medical leave. They allowed me and asked me to call them as soon as I reach home. I nodded yes slowly, trying to act as if I was sick. I am a terrible actor but dont know how they fell for it. When I reached home I completely forgot about the phone call. Phone rings and my mom answers the phone. It was the school staff. \"Hi, I am calling from the school. Is Vignesh there?\" and my mom replied \"Oh god, What has he done now?\". I was sitting there and laughed so hard. I am sure the staff must have got their answers."
              }
        ]
          
          return a;
    }
}

module.exports = exportedMethods;